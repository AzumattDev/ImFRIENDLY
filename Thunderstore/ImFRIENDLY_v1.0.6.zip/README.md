# Description

## Tired of getting hit by your own ballista? Me fuckin too. Protects tames as well. Enjoy.

`This mod is not needed on a server. It's client only. Install on each client that you wish to have the mod load.`

`Feel free to reach out to me on discord if you need manual download assistance.`

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***




> # Update Information (Latest listed first)

| `Version`   | `Update Notes`                                                                                                                                                                                                                  |
|-------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.6       | - Update for PTB 0.213.4   <br/> - Attempt fixing shooting players that didn't load the ammo on servers.                                                                                                                        |
| 1.0.5       | - Fix some issues on the live version. Fix target issue as well.                                                                                                                                                                |
| 1.0.4       | - Allow the code to work on the current PTB (0.213.3) even with the new changes to the turret as well as the live version (0.212.9) <br/> - Also, fix the fact I built it for PTB in the last release. Making it break on live. |
| 1.0.2/1.0.3 | - Fix the SFX issue on dedicated servers<br/> - 1.0.3, fix a fuckup in my logic                                                                                                                                                 |
| 1.0.1       | - Check for PvP flag                                                                                                                                                                                                            |
| 1.0.0       | - Initial Release                                                                                                                                                                                                               |